#!/usr/bin/env python3
# coding: utf-8
import argparse
import json
import logging
import os
import shutil
import sys
import traceback
from html import escape
from multiprocessing import Value
from urllib.parse import urlsplit

import ffmpeg
import m3u8
import requests
from lxml import html

PATH = os.path.dirname(os.path.realpath(__file__))
COOKIES_FILE = os.path.join(PATH, "cookies.json")

ORLY_BASE_HOST = "oreilly.com"  # PLEASE INSERT URL HERE

SAFARI_BASE_HOST = "learning." + ORLY_BASE_HOST
API_ORIGIN_HOST = "api." + ORLY_BASE_HOST

ORLY_BASE_URL = "https://www." + ORLY_BASE_HOST
SAFARI_BASE_URL = "https://" + SAFARI_BASE_HOST
API_ORIGIN_URL = "https://" + API_ORIGIN_HOST

class Display:
    BASE_FORMAT = logging.Formatter(
        fmt="[%(asctime)s] %(message)s",
        datefmt="%d/%b/%Y %H:%M:%S"
    )

    SH_DEFAULT = "\033[0m" if "win" not in sys.platform else ""  # TODO: colors for Windows
    SH_YELLOW = "\033[33m" if "win" not in sys.platform else ""
    SH_BG_RED = "\033[41m" if "win" not in sys.platform else ""
    SH_BG_YELLOW = "\033[43m" if "win" not in sys.platform else ""

    def __init__(self, log_file):
        self.log_file = os.path.join(PATH, log_file)

        self.logger = logging.getLogger("SafariVideos")
        self.logger.setLevel(logging.INFO)
        logs_handler = logging.FileHandler(filename=self.log_file)
        logs_handler.setFormatter(self.BASE_FORMAT)
        logs_handler.setLevel(logging.INFO)
        self.logger.addHandler(logs_handler)

        self.columns, _ = shutil.get_terminal_size()

        self.logger.info("** Welcome to SafariVideos! **")
        self.last_request = (None,)
        self.in_error = False

        self.state_status = Value("i", 0)
        sys.excepthook = self.unhandled_exception

    def unregister(self):
        self.logger.handlers[0].close()
        sys.excepthook = sys.__excepthook__

    def log(self, message):
        self.logger.info(str(message))  # TODO: "utf-8", "replace"

    def out(self, put):
        sys.stdout.write("\r" + " " * self.columns + "\r" + str(put) + "\n")  # TODO: "utf-8", "replace"

    def info(self, message, state=False):
        self.log(message)
        output = (self.SH_YELLOW + "[*]" + self.SH_DEFAULT if not state else
                  self.SH_BG_YELLOW + "[-]" + self.SH_DEFAULT) + " %s" % message
        self.out(output)

    def error(self, error):
        if not self.in_error:
            self.in_error = True

        self.log(error)
        output = self.SH_BG_RED + "[#]" + self.SH_DEFAULT + " %s" % error
        self.out(output)

    def exit(self, error):
        self.error(str(error))
        output = (self.SH_YELLOW + "[+]" + self.SH_DEFAULT +
                  " Please delete all the `<VIDEO NAME>`"
                  " files and restart the program.")
        self.out(output)

        output = self.SH_BG_RED + "[!]" + self.SH_DEFAULT + " Aborting..."
        self.out(output)

        self.save_last_request()
        sys.exit(1)

    def unhandled_exception(self, _, o, tb):
        self.log("".join(traceback.format_tb(tb)))
        self.exit("Unhandled Exception: %s (type: %s)" % (o, o.__class__.__name__))

    def save_last_request(self):
        if any(self.last_request):
            self.log("Last request done:\n\tURL: {0}\n\tDATA: {1}\n\tOTHERS: {2}\n\n\t{3}\n{4}\n\n{5}\n"
                     .format(*self.last_request))

    def intro(self):
        output = self.SH_YELLOW + """
       ____     ___         _
      / __/__ _/ _/__ _____(_)
     _\ \/ _ `/ _/ _ `/ __/ /
    /___/\_,_/_/ \_,_/_/ /_/
      / _ )___  ___  / /__ ___
     / _  / _ \/ _ \/  '_/(_-<
    /____/\___/\___/_/\_\/___/
""" + self.SH_DEFAULT
        output += "\n" + "~" * (self.columns // 2)

        self.out(output)

    def parse_description(self, desc):
        try:
            return html.fromstring(desc).text_content()

        except (html.etree.ParseError, html.etree.ParserError) as e:
            self.log("Error parsing the description: %s" % e)
            return "n/d"

    def video_info(self, info):
        for t in [
            ("Title", info["title"]),
            ("Authors", ", ".join(aut for aut in info["contributors"]["authors"])),
            ("Identifier", info["identifier"]), ("ISBN", info["isbn"])
        ]:
            self.info("{0}{1}{2}: {3}".format(self.SH_YELLOW, t[0], self.SH_DEFAULT, t[1]), True)

    def state(self, origin, done):
        progress = int(done * 100 / origin)
        bar = int(progress * (self.columns - 11) / 100)
        if self.state_status.value < progress:
            self.state_status.value = progress
            sys.stdout.write(
                "\r    " + self.SH_BG_YELLOW + "[" + ("#" * bar).ljust(self.columns - 11, "-") + "]" +
                self.SH_DEFAULT + ("%4s" % progress) + "%" + ("\n" if progress == 100 else "")
            )

    def done(self, epub_file):
        self.info("Done: %s\n\n" % epub_file +
                  "    If you like it, please * this project on GitHub to make it known:\n"
                  "        https://github.com/lorenzodifuccia/safarivideos\n"
                  "    e don't forget to renew your Safari Videos Online subscription:\n"
                  "        " + SAFARI_BASE_URL + "\n\n" +
                  self.SH_BG_RED + "[!]" + self.SH_DEFAULT + " Bye!!")

    @staticmethod
    def api_error(response):
        message = "API: "
        if "detail" in response and "Not found" in response["detail"]:
            message += "video's not present in Safari Videos Online.\n" \
                       "    The video identifier is the digits that you can find in the URL:\n" \
                       "    `" + SAFARI_BASE_URL + "/library/view/video-name/XXXXXXXXXXXXX/`"

        else:
            os.remove(COOKIES_FILE)
            message += "Out-of-Session%s.\n" % (" (%s)" % response["detail"]) if "detail" in response else "" +\
                       Display.SH_YELLOW + "[+]" + Display.SH_DEFAULT + \
                       " Use the `--cred` option in order to perform the auth login to Safari Videos Online."

        return message


class WinQueue(list):  # TODO: error while use `process` in Windows: can't pickle _thread.RLock objects
    def put(self, el):
        self.append(el)

    def qsize(self):
        return self.__len__()


class SafariVideos:
    LOGIN_URL = ORLY_BASE_URL + "/member/auth/login/"
    LOGIN_ENTRY_URL = SAFARI_BASE_URL + "/login/unified/?next=/home/"

    API_TEMPLATE = SAFARI_BASE_URL + "/api/v1/videoplaylists/{0}/?format=json"
    KALTURA_SESSION_URL = "https://learning.oreilly.com/api/v1/player/kaltura_session/?reference_id={0}"
    KALTURA_STREAMING_URL = "https://cdnapisec.kaltura.com/p/1926081/sp/192608100/playManifest/entryId/{0}/flavorIds/0/format/applehttp/protocol/https/a.m3u8?referrer=aHR0cHM6Ly9sZWFybmluZy5vcmVpbGx5LmNvbQ==&ks={1}"

    HEADERS = {
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "accept-encoding": "gzip, deflate",
        "accept-language": "it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7",
        "cache-control": "no-cache",
        "cookie": "",
        "pragma": "no-cache",
        "origin": SAFARI_BASE_URL,
        "referer": LOGIN_ENTRY_URL,
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/60.0.3112.113 Safari/537.36"
    }

    def __init__(self, args):
        self.args = args
        self.display = Display("info_%s.log" % escape(args.videoid))
        self.display.intro()

        self.cookies = {}
        self.jwt = {}

        if not args.cred:
            if not os.path.isfile(COOKIES_FILE):
                self.display.exit("Login: unable to find cookies file.\n"
                                  "    Please use the --cred option to perform the login.")

            self.cookies = json.load(open(COOKIES_FILE))

        else:
            self.display.info("Logging into Safari Videos Online...", state=True)
            self.do_login(*args.cred)
            if not args.no_cookies:
                json.dump(self.cookies, open(COOKIES_FILE, "w"))

        self.video_id = args.videoid
        self.resolution = args.resolution
        self.api_url = self.API_TEMPLATE.format(self.video_id)

        self.display.info("Retrieving video info...")
        self.video_info = self.get_video_info()
        self.display.video_info(self.video_info)

        self.display.info("Retrieving video chapters...")
        self.video_clips = self.video_info["video_clips"]

        self.video_clips_queue = self.video_clips[:]

        if len(self.video_clips) > sys.getrecursionlimit():
            sys.setrecursionlimit(len(self.video_clips))

        self.video_title = self.video_info["title"]

        self.clean_video_title = "".join(self.escape_dirname(self.video_title).split(",")[:2]) \
                                + " ({0})".format(self.video_id)

        videos_dir = os.path.join(PATH, "Videos")
        if not os.path.isdir(videos_dir):
            os.mkdir(videos_dir)

        self.VIDEO_PATH = os.path.join(videos_dir, self.clean_video_title)
        self.create_dirs()
        self.display.info("Output directory:\n    %s" % self.VIDEO_PATH)

        self.display.info("Downloading video contents... (%s chapters)" % len(self.video_clips), state=True)
        self.get()

        sys.exit(0)

    def return_cookies(self):
        return " ".join(["{0}={1};".format(k, v) for k, v in self.cookies.items()])

    def return_headers(self, url):
        if ORLY_BASE_HOST in urlsplit(url).netloc:
            self.HEADERS["cookie"] = self.return_cookies()

        else:
            self.HEADERS["cookie"] = ""

        return self.HEADERS

    def update_cookies(self, jar):
        for cookie in jar:
            if cookie.name != 'sessionid':
                self.cookies.update({
                    cookie.name: cookie.value
                })

    def requests_provider(
            self, url, post=False, data=None, perfom_redirect=True, update_cookies=True, update_referer=True, **kwargs
    ):
        try:
            response = getattr(requests, "post" if post else "get")(
                url,
                headers=self.return_headers(url),
                data=data,
                allow_redirects=False,
                **kwargs
            )

            self.display.last_request = (
                url, data, kwargs, response.status_code, "\n".join(
                    ["\t{}: {}".format(*h) for h in response.headers.items()]
                ), response.text
            )

        except (requests.ConnectionError, requests.ConnectTimeout, requests.RequestException) as request_exception:
            self.display.error(str(request_exception))
            return 0

        if update_cookies:
            self.update_cookies(response.cookies)

        if update_referer:
            # TODO Update Referer HTTP Header
            # TODO How about Origin? 
            self.HEADERS["referer"] = response.request.url

        if response.is_redirect and perfom_redirect:
            return self.requests_provider(response.next.url, post, None, perfom_redirect, update_cookies, update_referer)
            # TODO How about **kwargs?

        return response

    @staticmethod
    def parse_cred(cred):
        if ":" not in cred:
            return False

        sep = cred.index(":")
        new_cred = ["", ""]
        new_cred[0] = cred[:sep].strip("'").strip('"')
        if "@" not in new_cred[0]:
            return False

        new_cred[1] = cred[sep + 1:]
        return new_cred

    def do_login(self, email, password):
        response = self.requests_provider(self.LOGIN_ENTRY_URL)
        if response == 0:
            self.display.exit("Login: unable to reach Safari Videos Online. Try again...")

        redirect_uri = response.request.path_url[response.request.path_url.index("redirect_uri"):]  # TODO try...catch
        redirect_uri = redirect_uri[:redirect_uri.index("&")]
        redirect_uri = "https://api.oreilly.com%2Fapi%2Fv1%2Fauth%2Fopenid%2Fauthorize%3F" + redirect_uri

        response = self.requests_provider(
            self.LOGIN_URL,
            post=True,
            json={
                "email": email,
                "password": password,
                "redirect_uri": redirect_uri
            },
            perfom_redirect=False
        )

        if response == 0:
            self.display.exit("Login: unable to perform auth to Safari Videos Online.\n    Try again...")

        if response.status_code != 200:  # TODO To be reviewed
            try:
                error_page = html.fromstring(response.text)
                errors_message = error_page.xpath("//ul[@class='errorlist']//li/text()")
                recaptcha = error_page.xpath("//div[@class='g-recaptcha']")
                messages = (["    `%s`" % error for error in errors_message
                            if "password" in error or "email" in error] if len(errors_message) else []) +\
                           (["    `ReCaptcha required (wait or do logout from the website).`"] if len(recaptcha) else[])
                self.display.exit("Login: unable to perform auth login to Safari Videos Online.\n" +
                                  self.display.SH_YELLOW + "[*]" + self.display.SH_DEFAULT + " Details:\n"
                                  "%s" % "\n".join(messages if len(messages) else ["    Unexpected error!"]))
            except (html.etree.ParseError, html.etree.ParserError) as parsing_error:
                self.display.error(parsing_error)
                self.display.exit(
                    "Login: your login went wrong and it encountered in an error"
                    " trying to parse the login details of Safari Videos Online. Try again..."
                )

        self.jwt = response.json()  # TODO: save JWT Tokens and use the refresh_token to restore user session
        response = self.requests_provider(self.jwt["redirect_uri"])
        if response == 0:
            self.display.exit("Login: unable to reach Safari Videos Online. Try again...")

    def get_video_info(self):
        response = self.requests_provider(self.api_url)
        if response == 0:
            self.display.exit("API: unable to retrieve video info.")

        response = response.json()
        if not isinstance(response, dict) or len(response.keys()) == 1:
            self.display.exit(self.display.api_error(response))

        return response

    def get_video_clip_info(self, video):
        response = self.requests_provider(video)

        if response == 0:
            self.display.exit("API: unable to retrieve video info.")

        response = response.json()
        if not isinstance(response, dict) or len(response.keys()) == 1:
            self.display.exit(self.display.api_error(response))

        return response

    def get_video_clip_kaltura_session(self, reference_id):
        response = self.requests_provider(
            self.KALTURA_SESSION_URL.format(reference_id),
            post=False,
            perfom_redirect=False
        )

        if response == 0:
            self.display.exit("API: unable to retrieve video kaltura session.")

        response = response.json()
        if not isinstance(response, dict) or len(response.keys()) == 1:
            self.display.exit(self.display.api_error(response))

        return response

    def get_video_clip_kaltura_streaming(self, uri, output):

        m3u8_obj = m3u8.load(uri)

        if m3u8_obj.is_variant:
            fetch_playlist = None;
            for index, playlist in enumerate(m3u8_obj.playlists):
                try:
                    if self.resolution in "{}".format(playlist.stream_info.resolution):
                        print('Select resolution to download: {}'.format(playlist.stream_info.resolution))
                        fetch_playlist = playlist
                        break
                except:
                    print('Invalid index.')

            self.get_video_clip_kaltura_streaming(fetch_playlist.uri, output)

        else:
            # ffmpeg.output
            (ffmpeg
                .input(uri)
                .output(output, format='mp4', acodec='aac')
                .overwrite_output()
                .run(quiet = True)
            )

    @staticmethod
    def escape_dirname(dirname, clean_space=False):
        if ":" in dirname:
            if dirname.index(":") > 15:
                dirname = dirname.split(":")[0]

            elif "win" in sys.platform:
                dirname = dirname.replace(":", ",")

        for ch in ['~', '#', '%', '&', '*', '{', '}', '\\', '<', '>', '?', '/', '`', '\'', '"', '|', '+']:
            if ch in dirname:
                dirname = dirname.replace(ch, "_")

        return dirname if not clean_space else dirname.replace(" ", "")

    def create_dirs(self):
        if os.path.isdir(self.VIDEO_PATH):
            self.display.log("Video directory already exists: %s" % self.VIDEO_PATH)
        else:
            os.makedirs(self.VIDEO_PATH)

    def get(self):
        len_video_clips = len(self.video_clips)

        for _ in range(len_video_clips):
            if not len(self.video_clips_queue):
                return

            next_video_clip = self.video_clips_queue.pop(0)

            next_video_clip_info = self.get_video_clip_info(next_video_clip)
            next_video_clip_kaltura_session = self.get_video_clip_kaltura_session(next_video_clip_info["reference_id"])

            video_name = next_video_clip_info["reference_id"] + "-" + next_video_clip_info["title"] + ".mp4"
            video_name = self.escape_dirname(video_name)

            self.get_video_clip_kaltura_streaming(
                self.KALTURA_STREAMING_URL.format(
                    next_video_clip_info["kaltura_entry_id"],
                    next_video_clip_kaltura_session["session"]
                ),
                os.path.join(self.VIDEO_PATH, video_name)
            )

            self.display.state(len_video_clips, len_video_clips - len(self.video_clips_queue))

# MAIN
if __name__ == "__main__":
    arguments = argparse.ArgumentParser(prog="safarivideos.py",
                                        description="Download and generate an EPUB of your favorite videos"
                                                    " from Safari Videos Online.",
                                        add_help=False,
                                        allow_abbrev=False)

    arguments.add_argument(
        "--cred", metavar="<EMAIL:PASS>", default=False,
        help="Credentials used to perform the auth login on Safari Videos Online."
             " Es. ` --cred \"account_mail@mail.com:password01\" `."
    )
    arguments.add_argument(
        "--no-cookies", dest="no_cookies", action='store_true',
        help="Prevent your session data to be saved into `cookies.json` file."
    )
    arguments.add_argument(
        "--preserve-log", dest="log", action='store_true', help="Leave the `info_XXXXXXXXXXXXX.log`"
                                                                " file even if there isn't any error."
    )
    arguments.add_argument("--help", action="help", default=argparse.SUPPRESS, help='Show this help message.')

    arguments.add_argument(
        "videoid", metavar='<VIDEO ID>',
        help="Video digits ID that you want to download. You can find it in the URL (X-es):"
             " `" + SAFARI_BASE_URL + "/library/view/video-name/XXXXXXXXXXXXX/`"
    )

    arguments.add_argument(
        "resolution",
        metavar='<RESOLUTION>',
        help="Resolution of video",
        default='720'
    )

    args_parsed = arguments.parse_args()

    if args_parsed.cred:
        parsed_cred = SafariVideos.parse_cred(args_parsed.cred)
        if not parsed_cred:
            arguments.error("invalid credential: %s" % args_parsed.cred)

        args_parsed.cred = parsed_cred

    else:
        if args_parsed.no_cookies:
            arguments.error("invalid option: `--no-cookies` is valid only if you use the `--cred` option")

    SafariVideos(args_parsed)
